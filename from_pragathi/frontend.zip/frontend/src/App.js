import React from 'react'
import SearchOrganization from './SearchOrganization'

export default function App() {
  return (
    <div>
      <SearchOrganization/>
    </div>
  )
}

